# Hotels Management System
Hotels Management System - JavaFX Application
* Does this repo deserve a star? I hope that.
* Let's talk about what can my program do.
1. Register an account to manage a hotel.
2. Log into that account.
3. Manage your hotel.
4. You can add rooms to the hotel.
5. You can edit room's info.
6. You can also change your password.
7. And you can do more within main window.
* TIP: I made a default account with [admin, admin] login info, you can use it or sign up a new account.

* Illustrative pictures:
* ![login-window](https://user-images.githubusercontent.com/73291969/119761723-00fef900-beb5-11eb-985e-4cc41b2dda24.png)
* ![signup-window](https://user-images.githubusercontent.com/73291969/119761732-05c3ad00-beb5-11eb-82a5-2c9d3ec8c5c2.png)
* ![main-window](https://user-images.githubusercontent.com/73291969/119761745-0d835180-beb5-11eb-9068-9347fa580840.png)
* ![edit-password-window](https://user-images.githubusercontent.com/73291969/119761760-14aa5f80-beb5-11eb-8ee0-39fdf0810210.png)
* ![edit-room-window](https://user-images.githubusercontent.com/73291969/119761768-18d67d00-beb5-11eb-8ab7-72d70892cd31.png)
* ![add-rooms-window](https://user-images.githubusercontent.com/73291969/119761774-1c6a0400-beb5-11eb-93ed-38127ef40bd7.png)

 

